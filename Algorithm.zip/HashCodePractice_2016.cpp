// HashCodePractice_2016.cpp : Defines the entry point for the console application.
//

#include "Algorithm.h"


int main()
{
	//test();
	readFile("learn_and_teach.in");
	return 0;
}

